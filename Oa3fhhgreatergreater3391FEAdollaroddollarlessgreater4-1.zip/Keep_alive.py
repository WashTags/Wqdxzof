from flask import Flask
from threading import Thread
import time

app = Flask('')

@app.route('/')
def home():
    return "I'm alive!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

# Ping the server every 5 minutes to keep the bot alive
if __name__ == '__main__':
    keep_alive()
    while True:
        time.sleep(300)  # 5 minutes in seconds