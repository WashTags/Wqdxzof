import os
import discord

# Bot Configuration
BOT_TOKEN = 'MTE5ODI5MDk4NDUyNjY4NDI4MA.G58zLZ.LDtMgKxU1tvdxonM-UP7AJWGJUacZLn2JBZ5aM'

# Item Configuration
ITEMS = ['apple', 'pear', 'kiwi']
PREMIUM_ITEMS = ['watermelon', 'pineapple']

# Role Configuration
PREMIUM_ROLE_NAME = 'Premium'  # Make sure this matches the exact name of your premium role


# Directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'fruits/data/')

# Stock and Generated Message Formats
STOCK_FORMAT = "```{title}\n{stock}```"
GENERATED_FORMAT = "```{stock_type} {item} Generated\nUsername: {username}\nPassword: {password}```"

# Embed Configuration
EMBED_COLORS = {
    'stock': 0x3498db,  # Blue color for stock embed
    'generated': 0x2ecc71,  # Green color for generated embed
}

EMBED_CONFIG = {
    'title': 'Hello',
    'description': 'Your Custom Description',
    'color': 0xff5733,  # Replace with your desired color (orange in this example)
}

BOT_RESPONSE_EMBED = discord.Embed(
    title=EMBED_CONFIG['title'],
    description=EMBED_CONFIG['description'],
    color=EMBED_CONFIG['color']
)

# Channel Configuration
FREEGEN_CHANNEL_ID = 1198377729024852238  # Replace with the actual ID of your 'freegen' channel
PREMIUMGEN_CHANNEL_ID = 1198377761815932959  # Replace with the actual ID of your 'premiumgen' channel

