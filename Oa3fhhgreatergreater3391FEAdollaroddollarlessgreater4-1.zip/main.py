import discord
from discord.ext import commands
import os
import random
from config import BOT_TOKEN, ITEMS, PREMIUM_ITEMS, PREMIUM_ROLE_NAME, DATA_DIR, EMBED_COLORS, BOT_RESPONSE_EMBED, FREEGEN_CHANNEL_ID, PREMIUMGEN_CHANNEL_ID

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='/', intents=intents)

# Ensure the data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

async def send_stock_embed(ctx, title, regular_items, premium_items):
    embed = discord.Embed(title=title, color=EMBED_COLORS.get('stock', discord.Color.blue()))

    max_length = max(len(regular_items), len(premium_items))

    regular_info = "Regular Stock"
    premium_info = "Premium Stock"

    for i in range(max_length):
        if i < len(regular_items):
            regular_item = regular_items[i]
            regular_file_path = os.path.join(DATA_DIR, f'{regular_item.lower()}.txt')

            if os.path.exists(regular_file_path):
                with open(regular_file_path, 'r', encoding='utf-8', errors='ignore') as file:
                    data = file.readlines()
                    regular_info += f'\n{regular_item.capitalize()}: `{len(data)}`'

        if i < len(premium_items):
            premium_item = premium_items[i]
            premium_file_path = os.path.join(DATA_DIR, f'{premium_item.lower()}.txt')

            if os.path.exists(premium_file_path):
                with open(premium_file_path, 'r', encoding='utf-8', errors='ignore') as file:
                    data = file.readlines()
                    premium_info += f'\n{premium_item.capitalize()}: `{len(data)}`'

    embed.add_field(name=regular_info, value='\u200b', inline=True)
    embed.add_field(name=premium_info, value='\u200b', inline=True)

    await ctx.send(embed=embed)





async def generate_stock_embed(ctx, item, premium=False):
    stock_type = "Premium" if premium else "Regular"
    item_file_path = os.path.join(DATA_DIR, f'{item.lower()}.txt')

    print(f'User roles: {ctx.author.roles}')

    if premium and discord.utils.get(ctx.author.roles, name=PREMIUM_ROLE_NAME) is None:
        print(f'{ctx.author} does not have the {PREMIUM_ROLE_NAME} role.')
        await ctx.send(f'You need the {PREMIUM_ROLE_NAME} role to generate premium items.')
        return

    if os.path.exists(item_file_path):
        with open(item_file_path, 'r') as file:
            data = file.readlines()

            if data:
                random_entry = random.choice(data)
                data.remove(random_entry)

                with open(item_file_path, 'w') as write_file:
                    write_file.writelines(data)

                username, password = random_entry.strip().split(':')

                embed = discord.Embed(
                    title=f'{stock_type} {item.capitalize()} Generated',
                    description=f'**Username:** {username}\n**Password:** {password}',
                    color=EMBED_COLORS.get('generated', discord.Color.green())
                )

                dm_channel = await ctx.author.create_dm()
                await dm_channel.send(embed=embed)

                if len(data) == 1:
                    await ctx.send(f'Last {item.capitalize()} in {stock_type} stock left! Hurry before it runs out.')

                await send_stock_embed(ctx, f"Updated {stock_type} Stock", [item], [])  # Pass an empty list for premium_items
                await ctx.send(f'{ctx.author.mention} check your DMs for the generated {item.capitalize()}.')
            else:
                await ctx.send(f'No more entries for {item.capitalize()} in {stock_type} stock.')
    else:
        await ctx.send(f'Item {item} not found in {stock_type} stock.')




@bot.event
async def on_ready():
    print(f'We have logged in as {bot.user.name}')

@bot.command()
async def stock(ctx):
    if ctx.channel.id == FREEGEN_CHANNEL_ID or ctx.channel.id == PREMIUMGEN_CHANNEL_ID:
        await send_stock_embed(ctx, "Current Stock", ITEMS, PREMIUM_ITEMS)
    else:
        await ctx.send("This command can only be used in the 'freegen' or 'premiumgen' channels.")

# Rest of your commands...






@bot.command()
async def gen(ctx, service: str):
    if ctx.channel.id == FREEGEN_CHANNEL_ID:
        if service.lower() in PREMIUM_ITEMS:
            await ctx.send(f'You need the {PREMIUM_ROLE_NAME} role to generate premium items.')
            return
        await generate_stock_embed(ctx, service)
    else:
        await ctx.send("This command can only be used in the 'freegen' channel.")



@bot.command()
async def pstock(ctx):
    if ctx.channel.id == PREMIUMGEN_CHANNEL_ID:
        await send_stock_embed(ctx, "Premium Stock", PREMIUM_ITEMS)
    else:
        await ctx.send("This command can only be used in the 'premiumgen' channel.")

@bot.command()
async def pgen(ctx, item):
    if ctx.channel.id == PREMIUMGEN_CHANNEL_ID:
        # Check if the user has the 'Premium' role and if the item is a valid premium fruit
        if discord.utils.get(ctx.author.roles, name=PREMIUM_ROLE_NAME) and item.lower() in PREMIUM_ITEMS:
            await generate_stock_embed(ctx, item, premium=True)
        else:
            await ctx.send(f'You need the {PREMIUM_ROLE_NAME} role to use this command, or {item.capitalize()} is not a valid premium fruit.')
    else:
        await ctx.send(f'This command can only be used in the \'premiumgen\' channel.')


@bot.command()
async def botresponse(ctx):
    await ctx.send(embed=BOT_RESPONSE_EMBED)

# Replace 'YOUR_BOT_TOKEN' with your actual bot token
bot.run(BOT_TOKEN)
